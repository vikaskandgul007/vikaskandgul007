package Entity;

public class OtpClass {
	
	private String randomOtp;
	private String email;
	
	public String getRandomOtp() {
		return randomOtp;
	}
	public void setRandomOtp(String randomOtp) {
		this.randomOtp = randomOtp;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
